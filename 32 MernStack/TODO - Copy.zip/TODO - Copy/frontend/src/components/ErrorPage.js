import React from 'react'

function ErrorPage() {
  return (
    <div>Page is not available</div>
  )
}

export default ErrorPage